Source Code Pemrograman Perangkat Bergerak - 4.2: Input controls - Minggu Ke 8
